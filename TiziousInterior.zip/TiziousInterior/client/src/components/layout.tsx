import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Menu, X, Phone, Mail, Instagram, Facebook, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@assets/TIZIOUS_INTERIOR_(9)_1764773442465.png";

import TIZIOUS_INTERIOR__10_ from "@assets/TIZIOUS INTERIOR (10).png";

export function Navbar() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Services", href: "/services" },
    { name: "Portfolio", href: "/portfolio" },
    { name: "Contact", href: "/contact" },
  ];

  const isHome = location === "/";

  return (
    <nav
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300 border-b border-transparent",
        isScrolled || !isHome
          ? "bg-white/95 backdrop-blur-md border-border/40 shadow-sm py-2"
          : "bg-transparent py-6"
      )}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2">
            <img src={TIZIOUS_INTERIOR__10_} alt="Tizious Interior Design Studio" className="h-12 w-auto" />
            {/* <span className={cn("text-xl font-serif font-bold tracking-wider", (isScrolled || !isHome) ? "text-foreground" : "text-white")}>
              TIZIOUS
            </span> */}
          </a>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.name} href={link.href}>
              <a
                className={cn(
                  "text-sm font-medium tracking-wide uppercase transition-colors hover:text-primary",
                  location === link.href ? "text-primary" : ((isScrolled || !isHome) ? "text-foreground" : "text-white/90 hover:text-white")
                )}
              >
                {link.name}
              </a>
            </Link>
          ))}
          <Button 
            variant={isScrolled || !isHome ? "default" : "outline"} 
            className={cn(
              "ml-4 rounded-full px-6", 
              !isScrolled && isHome && "border-white text-white hover:bg-white hover:text-black"
            )}
            asChild
          >
            <Link href="/contact">Book Consultation</Link>
          </Button>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden p-2 text-primary"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu className={cn((!isScrolled && isHome) ? "text-white" : "text-foreground")} />}
        </button>
      </div>
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-background border-b shadow-lg animate-in slide-in-from-top-5">
          <div className="container mx-auto px-4 py-6 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link key={link.name} href={link.href}>
                <a
                  className={cn(
                    "text-lg font-medium py-2 border-b border-border/50",
                    location === link.href ? "text-primary" : "text-foreground"
                  )}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              </Link>
            ))}
            <Button className="mt-4 w-full rounded-full" asChild onClick={() => setIsMobileMenuOpen(false)}>
              <Link href="/contact">Book Consultation</Link>
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="bg-neutral-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <img src={logo} alt="Tizious" className="h-16 w-auto mb-6 brightness-0 invert opacity-90" />
            <p className="text-neutral-400 leading-relaxed mb-6">
              Crafting elegant interiors for modern living. Based in Jharpada, Bhubaneswar, we bring innovation and beauty to every space.
            </p>
            <div className="flex gap-4">
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary hover:text-black transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary hover:text-black transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-primary hover:text-black transition-colors">
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif text-xl mb-6 text-primary">Quick Links</h3>
            <ul className="space-y-3 text-neutral-400">
              <li><Link href="/"><a className="hover:text-white transition-colors">Home</a></Link></li>
              <li><Link href="/about"><a className="hover:text-white transition-colors">About Us</a></Link></li>
              <li><Link href="/services"><a className="hover:text-white transition-colors">Services</a></Link></li>
              <li><Link href="/portfolio"><a className="hover:text-white transition-colors">Portfolio</a></Link></li>
              <li><Link href="/contact"><a className="hover:text-white transition-colors">Contact</a></Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-serif text-xl mb-6 text-primary">Our Services</h3>
            <ul className="space-y-3 text-neutral-400">
              <li>Residential Interiors</li>
              <li>Commercial Spaces</li>
              <li>Modular Kitchens</li>
              <li>Wardrobe Design</li>
              <li>Turnkey Solutions</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-serif text-xl mb-6 text-primary">Contact Us</h3>
            <ul className="space-y-4 text-neutral-400">
              <li className="flex items-start gap-3">
                <Phone className="mt-1 text-primary" size={18} />
                <span>+91 90786 41155</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="mt-1 text-primary" size={18} />
                <span>info@tiziousinteriors.com</span>
              </li>
              <li className="flex items-start gap-3">
                <div className="mt-1 text-primary">📍</div>
                <span>Jharpada, Bhubaneswar,<br />Odisha, India</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-neutral-500 text-sm">
          <p>© 2025 Tizious Interior Design Studio. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
