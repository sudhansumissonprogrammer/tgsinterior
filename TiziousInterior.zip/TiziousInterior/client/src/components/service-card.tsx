import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  image?: string;
  index: number;
}

export function ServiceCard({ title, description, icon, image, index }: ServiceCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="h-full"
    >
      <Card className="h-full flex flex-col overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300 group bg-white dark:bg-neutral-900">
        {image && (
          <div className="relative h-48 overflow-hidden">
            <img 
              src={image} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors duration-300" />
            <div className="absolute top-4 right-4 bg-white/90 backdrop-blur p-2 rounded-full text-primary shadow-sm">
              {icon}
            </div>
          </div>
        )}
        <CardHeader className={image ? "pt-6" : "pt-8"}>
          {!image && <div className="mb-4 text-primary w-12 h-12">{icon}</div>}
          <CardTitle className="font-serif text-xl md:text-2xl group-hover:text-primary transition-colors">
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-grow">
          <CardDescription className="text-base leading-relaxed">
            {description}
          </CardDescription>
        </CardContent>
        <CardFooter className="pt-0 pb-6">
          <Button variant="ghost" className="p-0 hover:bg-transparent hover:text-primary gap-2 group/btn" asChild>
            <Link href="/contact">
              Get Quote <ArrowRight size={16} className="transition-transform group-hover/btn:translate-x-1" />
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
