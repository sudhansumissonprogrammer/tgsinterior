import { useState, useEffect } from "react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import Fade from "embla-carousel-fade";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

import slide1 from "@assets/stock_images/luxury_modern_bedroo_52b2f376.jpg";
import slide2 from "@assets/stock_images/luxury_living_room_i_d49efd2d.jpg";
import slide3 from "@assets/stock_images/modern_modular_kitch_dd3efbaf.jpg";

const slides = [
  {
    image: slide1,
    title: "Crafting Elegant Interiors",
    subtitle: "Transform your bedroom into a sanctuary of luxury and comfort.",
  },
  {
    image: slide2,
    title: "Modern Living Spaces",
    subtitle: "Sophisticated designs that blend functionality with aesthetics.",
  },
  {
    image: slide3,
    title: "Bespoke Modular Kitchens",
    subtitle: "Culinary spaces designed for the modern chef.",
  },
];

export function Hero() {
  const [emblaRef] = useEmblaCarousel(
    { loop: true, duration: 30 },
    [Autoplay({ delay: 5000 }), Fade()]
  );

  return (
    <div className="relative h-screen min-h-[600px] w-full overflow-hidden bg-black">
      <div className="absolute inset-0 z-0" ref={emblaRef}>
        <div className="flex h-full">
          {slides.map((slide, index) => (
            <div className="relative flex-[0_0_100%] h-full w-full" key={index}>
              <img
                src={slide.image}
                alt={slide.title}
                className="h-full w-full object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30" />
            </div>
          ))}
        </div>
      </div>

      <div className="relative z-10 container mx-auto px-4 h-full flex flex-col justify-center items-center text-center text-white pt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <h2 className="text-sm md:text-base uppercase tracking-[0.3em] mb-4 text-primary font-medium">
            Tizious Interior Design Studio
          </h2>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold mb-6 leading-tight max-w-4xl"
        >
          Crafting Elegant Interiors <br />
          <span className="italic font-light text-white/90">for Modern Living</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl font-light"
        >
          Experience the perfect blend of luxury, comfort, and functionality with our bespoke interior design solutions.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-black rounded-full px-8 h-14 text-lg" asChild>
            <Link href="/contact">Book Free Consultation</Link>
          </Button>
          <Button size="lg" variant="outline" className="bg-transparent text-white border-white hover:bg-white hover:text-black rounded-full px-8 h-14 text-lg gap-2" asChild>
            <Link href="/portfolio">
              View Portfolio <ArrowRight size={18} />
            </Link>
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
