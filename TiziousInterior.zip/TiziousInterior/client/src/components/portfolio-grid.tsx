import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { motion } from "framer-motion";
import { Plus } from "lucide-react";

interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
}

interface PortfolioGridProps {
  projects: Project[];
}

export function PortfolioGrid({ projects }: PortfolioGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {projects.map((project, index) => (
        <PortfolioItem key={project.id} project={project} index={index} />
      ))}
    </div>
  );
}

function PortfolioItem({ project, index }: { project: Project; index: number }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          viewport={{ once: true }}
          className="group relative cursor-pointer overflow-hidden rounded-lg shadow-md aspect-[4/3]"
        >
          <img
            src={project.image}
            alt={project.title}
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center text-center p-4">
            <p className="text-primary text-sm font-medium uppercase tracking-wider mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
              {project.category}
            </p>
            <h3 className="text-white font-serif text-2xl translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-100">
              {project.title}
            </h3>
            <div className="mt-4 bg-white/10 p-3 rounded-full text-white translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-150 backdrop-blur-sm">
              <Plus size={24} />
            </div>
          </div>
        </motion.div>
      </DialogTrigger>
      <DialogContent className="max-w-4xl w-[95vw] bg-white dark:bg-neutral-900 border-none p-0 overflow-hidden">
        <div className="flex flex-col md:flex-row h-[80vh] md:h-[600px]">
          <div className="w-full md:w-2/3 h-64 md:h-full bg-black">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-contain md:object-cover"
            />
          </div>
          <div className="w-full md:w-1/3 p-6 md:p-10 flex flex-col justify-center bg-white dark:bg-neutral-900">
            <p className="text-primary text-sm font-medium uppercase tracking-wider mb-2">
              {project.category}
            </p>
            <DialogTitle className="font-serif text-3xl md:text-4xl mb-6">
              {project.title}
            </DialogTitle>
            <DialogDescription className="text-base md:text-lg leading-relaxed mb-8">
              {project.description}
            </DialogDescription>
            <div className="mt-auto">
              <p className="text-sm text-muted-foreground mb-2">Interested in a similar design?</p>
              <a 
                href="/contact" 
                className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 w-full"
              >
                Get a Quote
              </a>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
