import { Navbar, Footer } from "@/components/layout";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

import office from "@assets/stock_images/home_office_interior_71d3eff5.jpg";

export default function About() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      
      {/* Header */}
      <div className="pt-32 pb-16 bg-black text-white text-center">
        <div className="container mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif font-bold mb-4"
          >
            About Us
          </motion.h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            We are creators of spaces that inspire and endure.
          </p>
        </div>
      </div>

      {/* Story */}
      <section className="py-20 container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="w-full lg:w-1/2">
            <img 
              src={office} 
              alt="Our Office" 
              className="rounded-lg shadow-2xl w-full h-auto"
            />
          </div>
          <div className="w-full lg:w-1/2">
            <h2 className="text-primary text-sm font-bold tracking-wider uppercase mb-2">Our Story</h2>
            <h3 className="font-serif text-3xl md:text-4xl font-bold mb-6 text-foreground">
              Passionate About Design
            </h3>
            <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
              Tizious Interior Design Studio is a premier interior design firm located in Jharpada, Bhubaneswar. 
              Founded with a vision to transform ordinary spaces into extraordinary experiences, we have grown into 
              a trusted name in the industry.
            </p>
            <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
              Our mission is simple: to bring innovation, beauty, and functionality into every space we touch. 
              Whether it's a cozy home or a bustling office, we believe that good design has the power to improve 
              quality of life.
            </p>
          </div>
        </div>
      </section>

      {/* Vision Mission Values */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-neutral-100">
              <h4 className="font-serif text-2xl font-bold mb-4 text-primary">Our Vision</h4>
              <p className="text-muted-foreground">
                To be the leading interior design studio in Odisha, known for our commitment to quality, innovation, 
                and customer satisfaction.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-neutral-100">
              <h4 className="font-serif text-2xl font-bold mb-4 text-primary">Our Mission</h4>
              <p className="text-muted-foreground">
                To deliver bespoke interior solutions that blend aesthetics with functionality, creating spaces 
                that truly reflect our clients' personalities.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm border border-neutral-100">
              <h4 className="font-serif text-2xl font-bold mb-4 text-primary">Our Values</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Integrity & Transparency</li>
                <li>• Creative Excellence</li>
                <li>• Client-First Approach</li>
                <li>• Sustainable Practices</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <WhatsAppButton />
      <Footer />
    </div>
  );
}
