import { Navbar, Footer } from "@/components/layout";
import { Hero } from "@/components/hero";
import { ServiceCard } from "@/components/service-card";
import { PortfolioGrid } from "@/components/portfolio-grid";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Star, Users, Clock, ShieldCheck, Paintbrush } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

import livingRoom from "@assets/stock_images/luxury_living_room_i_4a81ebbd.jpg";
import kitchen from "@assets/stock_images/modern_modular_kitch_9def21f8.jpg";
import bedroom from "@assets/stock_images/luxury_modern_bedroo_4eb0ac8f.jpg";

export default function Home() {
  const services = [
    {
      title: "Custom Interior Design",
      description: "Tailored design solutions that reflect your personality and lifestyle.",
      icon: <Paintbrush size={24} />,
      image: livingRoom,
    },
    {
      title: "Modular Kitchen Design",
      description: "Functional and stylish kitchens designed for modern culinary experiences.",
      icon: <ShieldCheck size={24} />,
      image: kitchen,
    },
    {
      title: "Bedroom Interior",
      description: "Create a peaceful sanctuary with our luxury bedroom designs.",
      icon: <Star size={24} />,
      image: bedroom,
    },
  ];

  const features = [
    { icon: <Paintbrush className="text-primary" />, title: "3D Designs", desc: "Visualize your space before execution." },
    { icon: <ShieldCheck className="text-primary" />, title: "Premium Finishing", desc: "High-quality materials and flawless finish." },
    { icon: <Users className="text-primary" />, title: "Dedicated Support", desc: "Personalized attention from expert designers." },
    { icon: <Clock className="text-primary" />, title: "Timely Delivery", desc: "We value your time and deliver on schedule." },
  ];

  const testimonials = [
    { name: "Priya Das", role: "Homeowner", text: "Tizious transformed our empty apartment into a dream home. The attention to detail is unmatched!" },
    { name: "Rahul Mishra", role: "Business Owner", text: "Professional, creative, and budget-friendly. Highly recommend their office interior services." },
    { name: "Anjali Sahoo", role: "Doctor", text: "I loved their modular kitchen designs. Very functional and elegant. Great team!" },
  ];

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      
      <Hero />

      {/* About Section */}
      <section className="py-20 container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-12 items-center">
          <div className="w-full md:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img 
                src={livingRoom} 
                alt="About Tizious" 
                className="rounded-lg shadow-2xl w-full h-auto object-cover aspect-[4/3]"
              />
            </motion.div>
          </div>
          <div className="w-full md:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="text-primary text-sm font-bold tracking-wider uppercase mb-2">About Us</h2>
              <h3 className="font-serif text-3xl md:text-4xl font-bold mb-6 text-foreground">
                Crafting Spaces that Tell Your Story
              </h3>
              <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                Tizious Interior Design Studio is a creative interior design company based in Jharpada, Bhubaneswar. 
                We specialize in bespoke home and office interiors, bringing innovation, beauty, and functionality into every space.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="text-primary" size={20} />
                  <span>Customer-centric approach tailored to your needs</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="text-primary" size={20} />
                  <span>Premium materials and superior craftsmanship</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 className="text-primary" size={20} />
                  <span>Experienced design professionals</span>
                </li>
              </ul>
              <Button asChild className="rounded-full px-8 bg-black text-white hover:bg-primary hover:text-black">
                <Link href="/about">Read More</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-primary text-sm font-bold tracking-wider uppercase mb-2">Our Expertise</h2>
            <h3 className="font-serif text-3xl md:text-4xl font-bold text-foreground">Design Services</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} index={index} {...service} />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button variant="outline" size="lg" className="rounded-full gap-2" asChild>
              <Link href="/services">View All Services <ArrowRight size={16} /></Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="p-6 border border-white/10 rounded-xl hover:bg-white/5 transition-colors text-center md:text-left"
              >
                <div className="bg-primary/20 p-3 rounded-full w-fit mb-4 mx-auto md:mx-0 text-primary">
                  {feature.icon}
                </div>
                <h4 className="font-serif text-xl font-bold mb-2">{feature.title}</h4>
                <p className="text-gray-400">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-primary text-sm font-bold tracking-wider uppercase mb-2">Testimonials</h2>
          <h3 className="font-serif text-3xl md:text-4xl font-bold text-foreground">What Our Clients Say</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-8 rounded-xl shadow-lg border border-neutral-100"
            >
              <div className="flex gap-1 mb-4 text-primary">
                {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
              </div>
              <p className="text-muted-foreground mb-6 italic">"{t.text}"</p>
              <div>
                <p className="font-bold font-serif text-lg">{t.name}</p>
                <p className="text-sm text-muted-foreground">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-secondary/50">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-12">
            <h3 className="font-serif text-3xl md:text-4xl font-bold text-foreground">Frequently Asked Questions</h3>
          </div>
          
          <Accordion type="single" collapsible className="w-full bg-white rounded-xl shadow-sm p-2">
            <AccordionItem value="item-1" className="border-b-0 px-4">
              <AccordionTrigger className="text-lg font-medium">How do you charge for your services?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                We offer both flat-fee packages and customized quotes based on the scope of work. Our pricing is transparent with no hidden costs.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2" className="border-b-0 px-4">
              <AccordionTrigger className="text-lg font-medium">What is your design process?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                Our process involves consultation, 2D/3D visualization, material selection, execution, and final handover. We keep you involved at every step.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3" className="border-b-0 px-4">
              <AccordionTrigger className="text-lg font-medium">What is the timeline for a project?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                Timelines vary by project size. A typical bedroom takes 2-3 weeks, while a full home interior can take 45-60 days.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4" className="border-b-0 px-4">
              <AccordionTrigger className="text-lg font-medium">Do you provide warranty on materials?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                Yes, we use premium materials that come with manufacturer warranties, ranging from 5 to 10 years depending on the product.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      <WhatsAppButton />
      <Footer />
    </div>
  );
}
