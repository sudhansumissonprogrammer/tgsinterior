import { Navbar, Footer } from "@/components/layout";
import { ServiceCard } from "@/components/service-card";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { motion } from "framer-motion";
import { 
  Bed, ChefHat, Warehouse, Briefcase, Armchair, Lightbulb, 
  Ruler, Home, Grid, Box 
} from "lucide-react";

// Import images for backgrounds
import bedroom from "@assets/stock_images/luxury_modern_bedroo_52b2f376.jpg";
import kitchen from "@assets/stock_images/modern_modular_kitch_dd3efbaf.jpg";
import wardrobe from "@assets/stock_images/modern_wardrobe_desi_2680b0a3.jpg";
import office from "@assets/stock_images/commercial_office_in_475f5878.jpg";
import living from "@assets/stock_images/luxury_living_room_i_d49efd2d.jpg";

export default function Services() {
  const services = [
    {
      title: "Custom Interior Design",
      description: "End-to-end interior design services tailored to your specific needs and preferences.",
      icon: <Home size={24} />,
      image: living
    },
    {
      title: "Bedroom Interior Design",
      description: "Create a relaxing retreat with our customized bedroom themes and layouts.",
      icon: <Bed size={24} />,
      image: bedroom
    },
    {
      title: "Modular Kitchen Design",
      description: "Ergonomic, stylish, and durable modular kitchens with premium finishes.",
      icon: <ChefHat size={24} />,
      image: kitchen
    },
    {
      title: "Wardrobe & Storage",
      description: "Maximize space with smart storage solutions and elegant wardrobe designs.",
      icon: <Box size={24} />,
      image: wardrobe
    },
    {
      title: "Office Interior Design",
      description: "Productive and inspiring workspaces designed for modern businesses.",
      icon: <Briefcase size={24} />,
      image: office
    },
    {
      title: "Living Room Decor",
      description: "Make a statement with a luxurious and welcoming living area.",
      icon: <Armchair size={24} />,
    },
    {
      title: "False Ceiling Design",
      description: "Enhance your space with modern POP and gypsum false ceiling designs.",
      icon: <Grid size={24} />,
    },
    {
      title: "Lighting Design",
      description: "Strategic lighting planning to create the perfect ambiance.",
      icon: <Lightbulb size={24} />,
    },
    {
      title: "Space Planning",
      description: "Optimizing layouts for better flow and functionality.",
      icon: <Ruler size={24} />,
    },
    {
      title: "Turnkey Solutions",
      description: "Complete project management from design to execution.",
      icon: <Warehouse size={24} />,
    },
  ];

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      
      {/* Header */}
      <div className="pt-32 pb-16 bg-black text-white text-center">
        <div className="container mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif font-bold mb-4"
          >
            Our Services
          </motion.h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Comprehensive interior design solutions for every space.
          </p>
        </div>
      </div>

      {/* Services Grid */}
      <section className="py-20 container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard key={index} index={index} {...service} />
          ))}
        </div>
      </section>

      <WhatsAppButton />
      <Footer />
    </div>
  );
}
