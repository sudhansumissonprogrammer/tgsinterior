import { Navbar, Footer } from "@/components/layout";
import { ContactForm } from "@/components/contact-form";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      
      {/* Header */}
      <div className="pt-32 pb-16 bg-black text-white text-center">
        <div className="container mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif font-bold mb-4"
          >
            Contact Us
          </motion.h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Ready to transform your space? Get in touch with us today.
          </p>
        </div>
      </div>

      <section className="py-20 container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Info */}
          <div className="w-full lg:w-1/3 space-y-8">
            <div>
              <h3 className="font-serif text-2xl font-bold mb-6 text-primary">Get In Touch</h3>
              <p className="text-muted-foreground mb-8">
                Fill out the form or contact us directly. We are happy to answer any questions you have about our services.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4 p-4 bg-white rounded-lg shadow-sm border border-neutral-100">
                  <div className="bg-primary/10 p-3 rounded-full text-primary">
                    <Phone size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground font-medium uppercase">Phone</p>
                    <p className="text-lg font-bold">+91 90786 41155</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 p-4 bg-white rounded-lg shadow-sm border border-neutral-100">
                  <div className="bg-primary/10 p-3 rounded-full text-primary">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground font-medium uppercase">Email</p>
                    <p className="text-lg font-bold">info@tiziousinteriors.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-white rounded-lg shadow-sm border border-neutral-100">
                  <div className="bg-primary/10 p-3 rounded-full text-primary">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground font-medium uppercase">Location</p>
                    <p className="text-lg font-bold">Jharpada, Bhubaneswar, Odisha</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="w-full lg:w-2/3">
            <ContactForm />
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="h-[400px] w-full bg-neutral-100">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59866.62064554718!2d85.80717686977539!3d20.2721907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a19a7a3b9692fff%3A0x87cd0a356bb2360d!2sJharpada%2C%20Bhubaneswar%2C%20Odisha!5e0!3m2!1sen!2sin!4v1708500000000!5m2!1sen!2sin" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>

      <WhatsAppButton />
      <Footer />
    </div>
  );
}
