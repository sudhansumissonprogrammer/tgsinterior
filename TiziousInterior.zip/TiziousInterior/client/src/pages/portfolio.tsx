import { Navbar, Footer } from "@/components/layout";
import { PortfolioGrid } from "@/components/portfolio-grid";
import { WhatsAppButton } from "@/components/whatsapp-button";
import { motion } from "framer-motion";

// Using the stock images multiple times to simulate a full portfolio
import img1 from "@assets/stock_images/luxury_modern_bedroo_52b2f376.jpg";
import img2 from "@assets/stock_images/luxury_modern_bedroo_4eb0ac8f.jpg";
import img3 from "@assets/stock_images/modern_modular_kitch_dd3efbaf.jpg";
import img4 from "@assets/stock_images/modern_modular_kitch_9def21f8.jpg";
import img5 from "@assets/stock_images/luxury_living_room_i_d49efd2d.jpg";
import img6 from "@assets/stock_images/luxury_living_room_i_4a81ebbd.jpg";
import img7 from "@assets/stock_images/home_office_interior_71d3eff5.jpg";
import img8 from "@assets/stock_images/modern_wardrobe_desi_2680b0a3.jpg";
import img9 from "@assets/stock_images/commercial_office_in_475f5878.jpg";

export default function Portfolio() {
  const projects = [
    {
      id: 1,
      title: "Luxury Master Bedroom",
      category: "Residential",
      image: img1,
      description: "A premium master bedroom designed with warmth and luxury in mind. Featuring a custom upholstered headboard, ambient lighting, and Italian marble flooring.",
    },
    {
      id: 2,
      title: "Contemporary Kitchen",
      category: "Kitchen",
      image: img3,
      description: "High-gloss modular kitchen with handle-less cabinets, built-in appliances, and a quartz countertop island for a sleek modern look.",
    },
    {
      id: 3,
      title: "Modern Living Area",
      category: "Living Room",
      image: img5,
      description: "Open-concept living room featuring a statement TV unit, plush seating, and gold accents that add a touch of glamour.",
    },
    {
      id: 4,
      title: "Home Office Setup",
      category: "Office",
      image: img7,
      description: "Ergonomic home office designed for productivity, with custom shelving, soundproofing, and optimal lighting.",
    },
    {
      id: 5,
      title: "Walk-in Wardrobe",
      category: "Storage",
      image: img8,
      description: "Spacious walk-in closet with glass shutters, sensor lighting, and organized compartments for accessories.",
    },
    {
      id: 6,
      title: "Corporate Office",
      category: "Commercial",
      image: img9,
      description: "Modern corporate office interior with collaborative workspaces, glass partitions, and brand-aligned color schemes.",
    },
    {
      id: 7,
      title: "Minimalist Bedroom",
      category: "Residential",
      image: img2,
      description: "A serene minimalist bedroom with neutral tones, natural wood textures, and maximizing natural light.",
    },
    {
      id: 8,
      title: "L-Shaped Kitchen",
      category: "Kitchen",
      image: img4,
      description: "Efficient L-shaped modular kitchen optimizing corner spaces with magic corners and tall pantry units.",
    },
    {
      id: 9,
      title: "Elegant Lounge",
      category: "Living Room",
      image: img6,
      description: "Sophisticated lounge area designed for entertaining guests, featuring a bespoke bar unit and designer furniture.",
    },
  ];

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      
      {/* Header */}
      <div className="pt-32 pb-16 bg-black text-white text-center">
        <div className="container mx-auto px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif font-bold mb-4"
          >
            Our Portfolio
          </motion.h1>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            A showcase of our finest work and design excellence.
          </p>
        </div>
      </div>

      {/* Portfolio Grid */}
      <section className="py-20 container mx-auto px-4">
        <PortfolioGrid projects={projects} />
      </section>

      <WhatsAppButton />
      <Footer />
    </div>
  );
}
